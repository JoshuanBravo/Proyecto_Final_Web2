<?php include("template/cabecera.php"); ?>

<div class="col-md-3">

<div class="card">

<img class="card-img-top" src="img/Español1.jpg" alt="" width="100px" height="250px">
    
    <div class="card-body">
        <h4 class="card-title">Español 1</h4>
        <p class="card-text">Libro de Español para Primer Grado</p>
        <a name="" id="" class="btn btn-primary" href="#" role="button"> Ver más </a>
    </div>

</div>
</div>

<div class="col-md-3">

<div class="card">

<img class="card-img-top" src="img/Español2.jpg" alt="" width="100px" height="250px">
    
    <div class="card-body">
        <h4 class="card-title">Español 2</h4>
        <p class="card-text">Libro de Español para Segundo Grado</p>
        <a name="" id="" class="btn btn-primary" href="#" role="button"> Ver más </a>
    </div>

</div>
</div>

<div class="col-md-3">

<div class="card">

<img class="card-img-top" src="img/Español3.jpg" alt="" width="100px" height="250px">
    
    <div class="card-body">
        <h4 class="card-title">Español 3</h4>
        <p class="card-text">Libro de Español para Tercer Grado</p>
        <a name="" id="" class="btn btn-primary" href="#" role="button"> Ver más </a>
    </div>

</div>
</div>

<div class="col-md-3">

<div class="card">

<img class="card-img-top" src="img/Español4.jpg" alt="" width="100px" height="250px">
    
    <div class="card-body">
        <h4 class="card-title">Español 4</h4>
        <p class="card-text">Libro de Español para Cuarto Grado</p>
        <a name="" id="" class="btn btn-primary" href="#" role="button"> Ver más </a>
    </div>

</div>
<br>
</div>



<div class="col-md-3">

<div class="card">

<img class="card-img-top" src="img/Español5.jpg" alt="" width="100px" height="250px">
    
    <div class="card-body">
        <h4 class="card-title">Español 5</h4>
        <p class="card-text">Libro de Español para Quinto Grado</p>
        <a name="" id="" class="btn btn-primary" href="#" role="button"> Ver más </a>
    </div>

</div>
</div>

<div class="col-md-3">

<div class="card">

<img class="card-img-top" src="img/Español6.jpg" alt="" width="100px" height="250px">
    
    <div class="card-body">
        <h4 class="card-title">Español 6</h4>
        <p class="card-text">Libro de Español para Sexto Grado</p>
        <a name="" id="" class="btn btn-primary" href="#" role="button"> Ver más </a>
    </div>

</div>
</div>

<div class="col-md-3">

<div class="card">

<img class="card-img-top" src="img/Ciencias1.jpg" alt="" width="100px" height="250px">
    
    <div class="card-body">
        <h4 class="card-title">Ciencias 1</h4>
        <p class="card-text">Libro de Ciencias para Primer Grado</p>
        <a name="" id="" class="btn btn-primary" href="#" role="button"> Ver más </a>
    </div>

</div>
</div>

<div class="col-md-3">

<div class="card">

<img class="card-img-top" src="img/Ciencias2.jpg" alt="" width="100px" height="250px">
    
    <div class="card-body">
        <h4 class="card-title">Ciencias 2</h4>
        <p class="card-text">Libro de Ciencias para Segundo Grado</p>
        <a name="" id="" class="btn btn-primary" href="#" role="button"> Ver más </a>
    </div>

</div>
<br>
</div>

<div class="col-md-3">

<div class="card">

<img class="card-img-top" src="img/Ciencias3.jpg" alt="" width="100px" height="250px">
    
    <div class="card-body">
        <h4 class="card-title">Ciencias 3</h4>
        <p class="card-text">Libro de Ciencias para Tercer Grado</p>
        <a name="" id="" class="btn btn-primary" href="#" role="button"> Ver más </a>
    </div>

</div>
</div>

<div class="col-md-3">

<div class="card">

<img class="card-img-top" src="img/Ciencias4.jpg" alt="" width="100px" height="250px">
    
    <div class="card-body">
        <h4 class="card-title">Ciencias 4</h4>
        <p class="card-text">Libro de Ciencias para Cuarto Grado</p>
        <a name="" id="" class="btn btn-primary" href="#" role="button"> Ver más </a>
    </div>

</div>
</div>

<div class="col-md-3">

<div class="card">

<img class="card-img-top" src="img/Ciencias5.jpg" alt="" width="100px" height="250px">
    
    <div class="card-body">
        <h4 class="card-title">Ciencias 5</h4>
        <p class="card-text">Libro de Ciencias para Quinto Grado</p>
        <a name="" id="" class="btn btn-primary" href="#" role="button"> Ver más </a>
    </div>

</div>
</div>

<div class="col-md-3">

<div class="card">

<img class="card-img-top" src="img/Ciencias6.jpg" alt="" width="100px" height="250px">
    
    <div class="card-body">
        <h4 class="card-title">Ciencias 6</h4>
        <p class="card-text">Libro de Ciencias para Sexto Grado</p>
        <a name="" id="" class="btn btn-primary" href="#" role="button"> Ver más </a>
    </div>

</div>
<br>
</div>

<div class="col-md-3">

<div class="card">

<img class="card-img-top" src="img/Matematica1.jpg" alt="" width="100px" height="250px">
    
    <div class="card-body">
        <h4 class="card-title">Matematicas 1</h4>
        <p class="card-text">Libro de Matematicas para Primer Grado</p>
        <a name="" id="" class="btn btn-primary" href="#" role="button"> Ver más </a>
    </div>

</div>
</div>

<div class="col-md-3">

<div class="card">

<img class="card-img-top" src="img/Matematica2.jpg" alt="" width="100px" height="250px">
    
    <div class="card-body">
        <h4 class="card-title">Matematicas 2</h4>
        <p class="card-text">Libro de Matematicas para Segundo Grado</p>
        <a name="" id="" class="btn btn-primary" href="#" role="button"> Ver más </a>
    </div>

</div>
</div>

<div class="col-md-3">

<div class="card">

<img class="card-img-top" src="img/Matematica3.jpg" alt="" width="100px" height="250px">
    
    <div class="card-body">
        <h4 class="card-title">Matematicas 3</h4>
        <p class="card-text">Libro de Matematicas para Tercer Grado</p>
        <a name="" id="" class="btn btn-primary" href="#" role="button"> Ver más </a>
    </div>

</div>
</div>

<div class="col-md-3">

<div class="card">

<img class="card-img-top" src="img/Matematica4.jpg" alt="" width="100px" height="250px">
    
    <div class="card-body">
        <h4 class="card-title">Matematicas 4</h4>
        <p class="card-text">Libro de Matematicas para Cuarto Grado</p>
        <a name="" id="" class="btn btn-primary" href="#" role="button"> Ver más </a>
    </div>

</div>
<br>
</div>

<div class="col-md-3">

<div class="card">

<img class="card-img-top" src="img/Matematica5.jpg" alt="" width="100px" height="250px">
    
    <div class="card-body">
        <h4 class="card-title">Matematicas 5</h4>
        <p class="card-text">Libro de Matematicas para Quinto Grado</p>
        <a name="" id="" class="btn btn-primary" href="#" role="button"> Ver más </a>
    </div>

</div>
</div>

<div class="col-md-3">

<div class="card">

<img class="card-img-top" src="img/Matematica6.jpg" alt="" width="100px" height="250px">
    
    <div class="card-body">
        <h4 class="card-title">Matematicas 6</h4>
        <p class="card-text">Libro de Matematicas para Sexto Grado</p>
        <a name="" id="" class="btn btn-primary" href="#" role="button"> Ver más </a>
    </div>

</div>
</div>

<div class="col-md-3">

<div class="card">

<img class="card-img-top" src="img/Sociales1.jpg" alt="" width="100px" height="250px">
    
    <div class="card-body">
        <h4 class="card-title">Estudios Sociales 1</h4>
        <p class="card-text">Libro de Estudios Sociales para Primer Grado</p>
        <a name="" id="" class="btn btn-primary" href="#" role="button"> Ver más </a>
    </div>

</div>
</div>

<div class="col-md-3">

<div class="card">

<img class="card-img-top" src="img/Sociales2.jpg" alt="" width="100px" height="250px">
    
    <div class="card-body">
        <h4 class="card-title">Estudios Sociales 2</h4>
        <p class="card-text">Libro de Estudios Sociales para Segundo Grado</p>
        <a name="" id="" class="btn btn-primary" href="#" role="button"> Ver más </a>
    </div>

</div>
<br>
</div>

<div class="col-md-3">

<div class="card">

<img class="card-img-top" src="img/Sociales3.jpg" alt="" width="100px" height="250px">
    
    <div class="card-body">
        <h4 class="card-title">Estudios Sociales 3</h4>
        <p class="card-text">Libro de Estudios Sociales para Tercer Grado</p>
        <a name="" id="" class="btn btn-primary" href="#" role="button"> Ver más </a>
    </div>

</div>
</div>

<div class="col-md-3">

<div class="card">

<img class="card-img-top" src="img/Sociales4.jpg" alt="" width="100px" height="250px">
    
    <div class="card-body">
        <h4 class="card-title">Estudios Sociales 4</h4>
        <p class="card-text">Libro de Estudios Sociales para Cuarto Grado</p>
        <a name="" id="" class="btn btn-primary" href="#" role="button"> Ver más </a>
    </div>

</div>
</div>

<div class="col-md-3">

<div class="card">

<img class="card-img-top" src="img/Sociales5.jpg" alt="" width="100px" height="250px">
    
    <div class="card-body">
        <h4 class="card-title">Estudios Sociales 5</h4>
        <p class="card-text">Libro de Estudios Sociales para Quinto Grado</p>
        <a name="" id="" class="btn btn-primary" href="#" role="button"> Ver más </a>
    </div>

</div>
</div>

<div class="col-md-3">

<div class="card">

<img class="card-img-top" src="img/Sociales6.jpg" alt="" width="100px" height="250px">
    
    <div class="card-body">
        <h4 class="card-title">Estudios Sociales 6</h4>
        <p class="card-text">Libro de Estudios Sociales para Sexto Grado</p>
        <a name="" id="" class="btn btn-primary" href="#" role="button"> Ver más </a>
    </div>

</div>
</div>

<?php include("template/pie.php"); ?>