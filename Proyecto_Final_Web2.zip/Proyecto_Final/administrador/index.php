<?php include("template/cabecera2.php"); ?>


<!doctype html>
<html lang="en">
  <head>
    <title>Administrador</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
    <br>
    <div class="container">
        <div class="row">

        <div class="col-md-4">
            
        </div>
            <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            Iniciar Sesión
                        </div>
                        <div class="card-body">

                            <form method="POST">

                            <div class = "form-group">
                            <label>Usuario</label>
                            <input type="text" class="form-control" name="usuario" placeholder="Ingresar Usuario">
                            </div>

                            <div class="form-group">
                            <label>Contraseña:</label>
                            <input type="password" class="form-control" name="contrasena" placeholder="Ingresar Contraseña">
                            </div>

                            <button type="submit" class="btn btn-primary" href="<?php echo $url;?>/administrador/inicio.php">Iniciar Sesión</button>

                            </form>         

                        </div>
                    </div>

            </div>
        </div>
    </div>

  </body>

  <?php include("template/pie.php"); ?>
</html>