<?php include("../template/cabecera.php"); ?>

<div class="jumbotron">
                <h1 class="display-3">Biblioteca Educativa</h1>
                <p class="lead">¡Hola Bienvenido!</p>
                <p class="lead">Aquí aprenderas sobre nuevos temas con nuestros libros de educación escolar <br> que están diseñados para reforzar aquellos temas que se te dificultan dependiendo del grado académico.</p>
                <hr class="my-2">
                <p>Más Informacion</p>
                <p class="lead">
                    <a class="btn btn-primary btn-lg" href="seccion/productos.php" role="button">Libros</a>
                </p>
        </div>

<?php include("../template/pie.php"); ?>