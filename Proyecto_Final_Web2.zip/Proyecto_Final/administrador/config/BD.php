<?php include("../template/cabecera.php"); ?>

<?php


//Instruccion de SQL - Conexión a BD
$host="localhost";
$bd="sitio_bd";
$usuario="root";
$contrasenia="";

try {
    $conexion=new PDO("mysql:host=$host;dbname=$bd",$usuario,$contrasenia);
    //if($conexion){echo "Conectado... a sistema";}
} catch (Exception $ex) {
    echo $ex->getMessage();
}

?>