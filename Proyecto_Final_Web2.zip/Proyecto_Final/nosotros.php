<?php include("template/cabecera.php"); ?>

    <div class="jumbotron">
        <h1 class="display-3">Nosotros</h1>
        <p class="lead"> Hola somos un grupo de personas dedicadas al desarrollo web en temas escolares, para ayudar a todas aquellas personas que aprendan aún mas dependiendo de su grado académico</p>
        <hr class="my-2">
    </div>

<?php include("template/pie.php"); ?>